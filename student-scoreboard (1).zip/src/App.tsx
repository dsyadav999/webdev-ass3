/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Header from './components/Header';
import StudentTable from './components/StudentTable';
import AddStudentForm from './components/AddStudentForm';
import StatsCards from './components/StatsCards';
import { Student } from './types';

export default function App() {
  const [students, setStudents] = useState<Student[]>([
    { id: '1', name: 'Aman', score: 78 },
    { id: '2', name: 'Jane Smith', score: 35 },
    { id: '3', name: 'Mike Ross', score: 40 }
  ]);

  const handleAddStudent = (name: string, score: number) => {
    const newStudent: Student = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      score
    };
    setStudents([...students, newStudent]);
  };

  const handleUpdateScore = (id: string, newScore: number) => {
    setStudents(prevStudents =>
      prevStudents.map(student =>
        student.id === id ? { ...student, score: newScore } : student
      )
    );
  };

  // Calculate statistics
  const total = students.length;
  const passed = students.filter(s => s.score >= 40).length;
  const avgScore = total > 0 ? students.reduce((acc, curr) => acc + curr.score, 0) / total : 0;

  return (
    <div className="app-container">
      <Header />
      <AddStudentForm onAddStudent={handleAddStudent} />
      <StatsCards total={total} passed={passed} avgScore={avgScore} />
      <StudentTable 
        students={students} 
        onUpdateScore={handleUpdateScore} 
      />
    </div>
  );
}
