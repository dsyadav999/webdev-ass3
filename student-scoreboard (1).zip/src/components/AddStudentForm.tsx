import React, { useState } from 'react';

interface AddStudentFormProps {
  onAddStudent: (name: string, score: number) => void;
}

const AddStudentForm: React.FC<AddStudentFormProps> = ({ onAddStudent }) => {
  const [name, setName] = useState('');
  const [score, setScore] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && score !== '') {
      onAddStudent(name, parseInt(score));
      setName('');
      setScore('');
    }
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <div className="section-title">
          <div className="status-dot"></div>
          Register Student
        </div>
        <div className="section-meta">NEW ENTRY</div>
      </div>
      <form className="add-student-form" onSubmit={handleSubmit}>
        <div className="form-field">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="STUDENT NAME"
            required
          />
        </div>
        <div className="form-field">
          <input
            type="number"
            value={score}
            onChange={(e) => setScore(e.target.value)}
            placeholder="SCORE (0-100)"
            required
            min="0"
            max="100"
          />
        </div>
        <button type="submit" className="add-btn">+ ADD</button>
      </form>
    </div>
  );
};

export default AddStudentForm;
