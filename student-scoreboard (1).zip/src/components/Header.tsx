import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="app-header">
      <h1>STUDENT <span>SCOREBOARD</span></h1>
    </header>
  );
};

export default Header;
