import React, { useState } from 'react';
import { Student } from '../types';

interface StudentRowProps {
  student: Student;
  onUpdateScore: (id: string, newScore: number) => void;
}

const StudentRow: React.FC<StudentRowProps> = ({ student, onUpdateScore }) => {
  const [tempScore, setTempScore] = useState(student.score);
  const isPass = student.score >= 40;

  const handleSave = () => {
    onUpdateScore(student.id, tempScore);
  };

  return (
    <tr className="student-row">
      <td>{student.name}</td>
      <td>{student.score}</td>
      <td>
        <div className={`status-pill ${isPass ? 'pass' : 'fail'}`}>
          <div className="status-indicator"></div>
          {isPass ? 'Pass' : 'Fail'}
        </div>
      </td>
      <td>
        <div className="update-cell">
          <input
            type="number"
            value={tempScore}
            onChange={(e) => setTempScore(parseInt(e.target.value) || 0)}
            className="update-input"
          />
          <button className="save-btn" onClick={handleSave}>Save</button>
        </div>
      </td>
    </tr>
  );
};

export default StudentRow;
