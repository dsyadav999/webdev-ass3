import React from 'react';
import { Student } from '../types';
import StudentRow from './StudentRow';

interface StudentTableProps {
  students: Student[];
  onUpdateScore: (id: string, newScore: number) => void;
}

const StudentTable: React.FC<StudentTableProps> = ({ students, onUpdateScore }) => {
  return (
    <div className="section-container">
      <div className="section-header">
        <div className="section-title">STUDENT RECORDS</div>
        <div className="section-meta">{students.length} Entries</div>
      </div>
      <table className="student-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Score</th>
            <th>Status</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <StudentRow
              key={student.id}
              student={student}
              onUpdateScore={onUpdateScore}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentTable;
