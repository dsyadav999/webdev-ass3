import React from 'react';

interface StatsCardsProps {
  total: number;
  passed: number;
  avgScore: number;
}

const StatsCards: React.FC<StatsCardsProps> = ({ total, passed, avgScore }) => {
  return (
    <div className="stats-container">
      <div className="stat-card">
        <span className="stat-label">Total</span>
        <div className="stat-value">{total}</div>
      </div>
      <div className="stat-card">
        <span className="stat-label">Passed</span>
        <div className="stat-value">{passed}</div>
      </div>
      <div className="stat-card">
        <span className="stat-label">Avg Score</span>
        <div className="stat-value">{avgScore.toFixed(0)}</div>
      </div>
    </div>
  );
};

export default StatsCards;
